def hh2dd(value_hh):
	dd = value_hh *  15.0	
	return (dd)

dd = hh2dd(7.8383027778)
print dd