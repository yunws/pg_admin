def dd2hh(value_dd):
	hh = value_dd / 15.0	
	return (hh)

hh = dd2hh(117.574541667)
print hh